// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:flutter/material.dart';

// class LoginSignUpManagement {
//   // Future<bool> checkIfUserExists(String email) async {

//   //   // print(ans);
//   //   // return ans;
//   // }
// }
